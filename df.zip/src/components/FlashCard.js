import {useState,useEffect, useContext} from 'react';
import { AppContext, kanjiapiBase } from '../logic/reducer';

const FlashCard = ({character})=>{

    const [clickStyle,setClickStyle] = useState('');
    const {dispatch} = useContext(AppContext);
    const [meaning,setMeaning] = useState(null);

    const handleCardClick = () => {

        setClickStyle((prev) =>{
            if(prev==='') return ' card-clicked';
            return '';
        });
    }

    useEffect(async ()=>{
        await fetch(kanjiapiBase + character)
            .then(x=>x.json())
            .then(x=>{
                setMeaning(x);
            })
    })

    return (
        <div className='flash-card' onClick={handleCardClick} >
            <div className={'flash-card-inner' + clickStyle}>
                <div className="card-front">
                    <h1>{character}</h1>
                </div>
                <div className="card-back">
                    <p>{meaning && meaning.meanings}</p>
                </div>
            </div>
        </div>
    );
}

export default FlashCard;