import React, { useReducer } from "react";
import FlashCard from "./components/FlashCard";
import { AppContext, reducer } from "./logic/reducer";

function App() {
  
  const [state,dispatch] = useReducer(reducer,{});
  return (
    <AppContext.Provider value={{state,dispatch}}>
    <div className="App">
          
   </div>
    </AppContext.Provider>
  );
}

export default App;
