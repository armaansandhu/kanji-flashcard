import React from "react";

export const kanjiapiBase = "https://kanjiapi.dev/v1/kanji/";

export const AppContext = React.createContext();

export const reducer =  (state,action) =>{
    if (action.type === 'GET_CHARACTER_DATA'){
        var data;
       

        console.log(data);
        return state;
    }
}